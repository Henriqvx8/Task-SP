
# Task-SP 🚀

Projeto criado para automatizar atividades da Sala do Futuro e CMSP.  
Feito com HTML, CSS e JavaScript.  

## ✔️ Como usar:
1. Faça login com RA e senha.  
2. Selecione atividades pendentes ou expiradas.  
3. Escolha uma atividade e tempo simulado.  
4. Rode scripts extras na pasta `/scripts`.  

## 🌐 Como hospedar:
- Suba no GitHub e ative o GitHub Pages no repositório.
