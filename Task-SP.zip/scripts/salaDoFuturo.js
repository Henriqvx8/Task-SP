
alert('🔗 Conectando na Sala do Futuro...');
setTimeout(() => {
    alert('✅ Tarefa encontrada e preenchida com sucesso!');
}, 2000);
